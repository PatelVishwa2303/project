let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

function renderTasks() {
    const taskList = document.querySelector('.task-list');
    taskList.innerHTML = ''; // Clear the list

    tasks.forEach((task, index) => {
        const newTask = document.createElement('li');
        newTask.classList.toggle('completed', task.completed);

        // Create task text
        const taskText = document.createElement('span');
        taskText.textContent = task.text;

        // Create task date
        const taskDate = document.createElement('span');
        taskDate.textContent = task.date ? `Due: ${new Date(task.date).toLocaleDateString()}` : '';

        // Create complete button
        const completeButton = document.createElement('button');
        completeButton.textContent = task.completed ? 'Undo' : 'Complete';
        completeButton.onclick = () => toggleComplete(index);

        // Create edit button
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = () => editTask(index);

        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = () => deleteTask(index);

        // Append elements to the task item
        newTask.appendChild(taskText);
        newTask.appendChild(taskDate);
        newTask.appendChild(completeButton);
        newTask.appendChild(editButton);
        newTask.appendChild(deleteButton);
        taskList.appendChild(newTask);
    });
}

function addTask() {
    const inputField = document.getElementById('inputtask');
    const inputDate = document.getElementById('inputdate');
    const taskValue = inputField.value.trim();
    const taskDate = inputDate.value;

    if (taskValue) {
        tasks.push({ text: taskValue, date: taskDate, completed: false });
        inputField.value = '';
        inputDate.value = ''; // Clear date input
        saveTasks();
        renderTasks();
    }
}

function toggleComplete(index) {
    tasks[index].completed = !tasks[index].completed;
    saveTasks();
    renderTasks();
}

function editTask(index) {
    const inputField = document.getElementById('inputtask');
    const inputDate = document.getElementById('inputdate');
    inputField.value = tasks[index].text; // Populate input for editing
    inputDate.value = tasks[index].date; // Populate date for editing
    tasks.splice(index, 1); // Remove task for re-adding later
    saveTasks();
    renderTasks();
}

function deleteTask(index) {
    tasks.splice(index, 1); // Remove the task from the array
    saveTasks();
    renderTasks();
}

function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Initial render
renderTasks();
